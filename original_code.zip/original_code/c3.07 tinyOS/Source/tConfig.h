#ifndef TCONFIG_H
#define TCONFIG_H

#define	TINYOS_PRO_COUNT	32
#define	TINYOS_SLICE_MAX	10

#endif
